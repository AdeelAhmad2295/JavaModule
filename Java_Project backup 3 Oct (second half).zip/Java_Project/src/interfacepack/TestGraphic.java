package interfacepack;

public class TestGraphic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("================CIRCLE====================");
		Circle circle=new Circle(11f);
		System.out.println("Area of Circle: "+circle.area());
		System.out.println("perimeter : "+circle.perimeter());
		
		System.out.println("===============RECTANGLE==================");
		Rectangle rectangle=new Rectangle(5, 3);
		System.out.println("Rectangle: "+rectangle.area());
		System.out.println("Perimeter: "+rectangle.perimeter());
	}

}
