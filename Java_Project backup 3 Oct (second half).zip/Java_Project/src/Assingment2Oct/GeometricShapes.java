package Assingment2Oct;

public class GeometricShapes {

    abstract static class GeometricShape {
        abstract public double area();
        abstract public double perimeter();
    }

    static class Circle extends GeometricShape {
        private double radius;

        public Circle(double radius) {
            this.radius = radius;
        }

        @Override
        public double area() {
            return Math.PI * radius * radius;
        }

        @Override
        public double perimeter() {
            return 2 * Math.PI * radius;
        }
    }

    // Concrete subclass: Rectangle
    static class Rectangle extends GeometricShape {
        private double width;
        private double height;

        public Rectangle(double width, double height) {
            this.width = width;
            this.height = height;
        }

        @Override
        public double area() {
            return width * height;
        }

        @Override
        public double perimeter() {
            return 2 * (width + height);
        }
    }

    // Concrete subclass: Triangle
    static class Triangle extends GeometricShape {
        private double base;
        private double height;
        private double side1;
        private double side2;
        private double side3;

        public Triangle(double base, double height, double side1, double side2, double side3) {
            this.base = base;
            this.height = height;
            this.side1 = side1;
            this.side2 = side2;
            this.side3 = side3;
        }

        @Override
        public double area() {
            return (base * height) / 2;
        }

        @Override
        public double perimeter() {
            return side1 + side2 + side3;
        }
    }

    public static void main(String[] args) {
        GeometricShape circle = new Circle(5);
        System.out.println("Circle Area: " + circle.area());
        System.out.println("Circle Perimeter: " + circle.perimeter());

        GeometricShape rectangle = new Rectangle(4, 6);
        System.out.println("Rectangle Area: " + rectangle.area());
        System.out.println("Rectangle Perimeter: " + rectangle.perimeter());

        GeometricShape triangle = new Triangle(4, 3, 3, 4, 5);
        System.out.println("Triangle Area: " + triangle.area());
        System.out.println("Triangle Perimeter: " + triangle.perimeter());
    }
}
