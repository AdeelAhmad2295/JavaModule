/*
create an immutable class called person with final fields for name and age provide a constructor to initialize these fields
and make sure that once the object is created the values cannot be changed.
 * */

package Assingment2Oct;

class TestPerson {
    private final String name;
    private final int age;

    // Constructor to initialize fields
    public TestPerson(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Method to display person details
    public void display() {
        System.out.println("Name of Person: " + name + "\nAge of Person: " + age);
    }
}

public class Person {
    public static void main(String[] args) {
        // Creating a TestPerson object using the constructor
        TestPerson per1 = new TestPerson("Adeel", 22);

        // Accessing fields via getters
        System.out.println("Accessing via getters:");
        System.out.println("Name: " + per1.getName());
        System.out.println("Age: " + per1.getAge());
    }
}

