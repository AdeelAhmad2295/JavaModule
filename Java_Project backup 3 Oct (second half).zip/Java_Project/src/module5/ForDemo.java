package module5;

public class ForDemo {

	public static void main(String asdf[])
	{
		for(int i=1;i<=15;i++)
		{
			if(i==7)
				break;
			System.out.println(i);
		}
		System.out.println("==================================");
		for(int j=1;j<=15;j++)
		{
			if(j==8)
				continue;
			System.out.println(j);// 8 is skipped
		}
	}
}
