package module5;

public class OverLoading {
    static public int add (int a,int b)
    {
     return(a+b);	
    }
    static public int add (int a,int b, int c)
    {
     return(a+b+c);	
    }
    static public double add (int a,double b)
    {
     return(a+b);	
    }
    static public double add (double a,double b)
    {
     return(a+b);	
    }
	public static void main(String[] args) {
	
		int result=add(10,50);
		System.out.println(result);
		int result1=add(10,50,30);
		System.out.println(result1);
		double result2=add(10,55.32);
		System.out.println(result2);
		double result3=add(11.34,59.23);
		System.out.println(result3);
	}

}
