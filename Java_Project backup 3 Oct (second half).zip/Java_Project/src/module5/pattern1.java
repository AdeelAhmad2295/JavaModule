package module5;

public class pattern1 {

}
