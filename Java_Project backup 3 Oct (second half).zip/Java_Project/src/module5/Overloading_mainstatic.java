package module5;

public class Overloading_mainstatic {

	 static public void main()
	{
		System.out.println("main method without parameters");
	}
	 static public void main(int a)
	{
		System.out.println("main method with 1 parameters");
	}
	 static	public void main(int a, int b)
	{
		System.out.println("main method with 2 parameters");
	}
	 static public void main(int a, int b,double c)
	{
		System.out.println("main method with 3 parameters");
	}
	 static	public void main(double a, double b,double c,double e)
	{
		System.out.println("main method with 4 parameters");
	}
	 public static void main(String afsa[])
	 {
		main(13);
		 main();
		 main(12,23);
		 main(12,23,34.45);
		main(12.25,23.35,34.45,45.55);
	 }
}
