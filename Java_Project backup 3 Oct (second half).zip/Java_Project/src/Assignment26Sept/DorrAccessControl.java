/*
Assignment 3: Door Access Control
Write a program that simulates an access control system. A person is allowed access if they have both a valid ID and a 
valid access card, or if they are an admin.
Requirements:
•    Use logical operators &&, ||, and !.*/
package Assignment26Sept;
import java.util.*;
public class DorrAccessControl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your ID (true for valid, false for invalid): ");
        boolean hasValidID = scanner.nextBoolean();
        System.out.print("Enter your Access Card status (true for valid, false for invalid): ");
        boolean hasValidAccessCard = scanner.nextBoolean();
        System.out.print("Are you an admin? (true for yes, false for no): ");
        boolean isAdmin = scanner.nextBoolean();
        if ((hasValidID && hasValidAccessCard) || isAdmin) {
            System.out.println("Access Granted.");
        } else {
            System.out.println("Access Denied.");
        }
	}

}
