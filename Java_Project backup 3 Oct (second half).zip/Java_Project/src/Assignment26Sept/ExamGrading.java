/*
Assignment 2: Exam Grading System
Write a program that determines whether a student passes an exam based on three subjects. A student passes if the average score
is at least 60, and none of the individual scores is below 40.
Requirements:
•    Use logical operators && and || to combine conditions.
 */
package Assignment26Sept;
import java.util.*;
public class ExamGrading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int s1,s2,s3;
		double avg;
		System.out.println("Enter the marks for Subject-1: ");
		s1=s.nextInt();
		System.out.println("Enter the marks for Subject-2: ");
		s2=s.nextInt();
		System.out.println("Enter the marks for Subject-3: ");
		s3=s.nextInt();
		avg=(s1+s2+s3)/3.0;
		if(avg>=60 && s1>40 && s2>40 && s3>40) {
			System.out.println("Student is Pass.");
		}
		else {
			System.out.println("Student is Fail.");
		}
	}

}
