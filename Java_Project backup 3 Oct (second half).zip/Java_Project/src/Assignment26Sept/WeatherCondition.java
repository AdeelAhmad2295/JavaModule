/**
Assignment 7: Weather Conditions
Write a program that determines whether it's safe to go outside based on temperature and weather conditions.
The conditions to go outside are:
•Temperature should be between 20°C and 30°C.
•It should not be raining.
Requirements:
•Use logical operators && and !.
 */

package Assignment26Sept;
import java.util.*;
public class WeatherCondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		System.out.println("Enter the temperature:");
		int temp=s.nextInt();
		if(temp>=20 && temp<=30) {
			System.out.println("It should not be raining today,it's safe to go outside.");
		}
		else {
			System.out.println("It should be raining today,it's not safe to go outside.");
		}
	}

}
