package module3;

import java.util.Scanner;

public class GreatestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int num1,num2;
		System.out.println("Enter a num1: ");
		num1=s.nextInt();
		System.out.println("Enter a num2: ");
		num2=s.nextInt();
		if(num1>num2) {
			System.out.println(num1+" is greater..");
		}
		else if(num1<num2) {
			System.out.println(num2+" is greater");
		}
		else {
			System.out.println("Numbers are equal");
		}
	}

}
