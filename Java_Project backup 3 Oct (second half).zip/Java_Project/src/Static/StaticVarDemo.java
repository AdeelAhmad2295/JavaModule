package Static;

public class StaticVarDemo {
	static int num=1;
	public void display() {
		num++;
		System.out.println(num);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(num);//1 Method to initialize the static variable will automatically compile.
		System.out.println(StaticVarDemo.num);//2nd method it is working because it is class level
		StaticVarDemo obj=new StaticVarDemo();
		obj.display();//3rd method calling with object
		StaticVarDemo obj1=new StaticVarDemo();
		obj1.display();//3rd method calling with object
	}

}
         