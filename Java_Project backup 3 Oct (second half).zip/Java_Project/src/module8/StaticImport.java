package module8;
import static java.lang.Math.*;
public class StaticImport {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(pow(3,4));
		System.out.println(sqrt(144));
		System.out.println(abs(-55));
		System.out.println(min(35, 45));
		System.out.println(max(54, 75));
		System.out.println(random());
		System.out.println(random()*100);
		System.out.println(ceil(979.45));
		System.out.println(floor(979.66));
		System.out.println(round(755.45));
		System.err.println(pow(4,3));
		System.out.println(nextUp(5));
	}
}
