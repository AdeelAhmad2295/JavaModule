package module6;

public class CustomerClass {
	private int cusId;
	private String name;
	private String mob;
	private String address;
	
	public CustomerClass() {
		cusId=0;
		name="null";
		mob="null";
		address="null";
	}

	public int getCusId() {
		return cusId;
	}

	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
//@Override
//	public String toString() {
//		return "CustomerClass [cusId=" + cusId + ", name=" + name + ", mob=" + mob + ", address=" + address + "]";
//	}

	public String toString() {
		return "Customer ID is "+cusId+"\nCustomer Name is "+name+"\nCustomer Mobile No. is "+mob+"\nCustomer Address is "+address;
	}
	public CustomerClass(int cusId, String name, String mob,String address) {
	super();
	System.out.println("Parameterized constructor call.....");
	this.cusId = cusId;
	this.name = name;
	this.mob= mob;
	this.address=address;
}
}
