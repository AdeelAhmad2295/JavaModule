package module6;

public class WrapperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="100";
		String str1="200";
		String str2="241.45";
		String str3="200.78";
		System.out.println("Integer total is "+(Integer.parseInt(str)+(Integer.parseInt(str1))));
		System.out.println("============================================");
		System.out.println("Double total is "+(Double.parseDouble(str2)+(Double.parseDouble(str3))));
		System.out.println("============================================");
		System.out.println("Float total is "+(Float.parseFloat(str2)+(Float.parseFloat(str3))));
		System.out.println("============================================");
		System.out.println("Byte "+Byte.MAX_VALUE);	
		System.out.println("Byte "+Byte.MIN_VALUE);
		System.out.println("============================================");
		System.out.println("Short "+Short.MAX_VALUE);
		System.out.println("============================================");
		System.out.println("Interger "+Integer.MAX_VALUE);
		System.out.println("============================================");
		System.out.println("Long "+Long.MAX_VALUE);


	}

}
