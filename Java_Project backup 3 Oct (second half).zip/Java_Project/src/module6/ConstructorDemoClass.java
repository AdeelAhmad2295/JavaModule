package module6;

public class ConstructorDemoClass {
	private int rollNo;
	private String name;
	private double score;
	
	public ConstructorDemoClass() {
		rollNo=0;
		name="null";
		score=0.0;
	}
//	public ConstructorDemoClass(int rollNo,String name,double score) {
//		System.out.println("parameterized Constructor call...");
//		this.rollNo=rollNo;
//		this.name=name;
//		this.score=score;
//	}
	
//	public void display() {
//		System.err.println("Roll no "+rollNo);
//		System.out.println("Name "+name);
//		System.out.println("Score "+score);
//	}
	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public ConstructorDemoClass(int rollNo, String name, double score) {
	super();
	System.out.println("Parameterized constructor call.....");
	this.rollNo = rollNo;
	this.name = name;
	this.score = score;
}
	public void markAttendance() {
		System.out.println("attendance marked....");
	}
	
}
