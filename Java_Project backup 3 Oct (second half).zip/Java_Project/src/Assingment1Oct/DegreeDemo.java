package Assingment1Oct;

class Degree {
    public void getDegree() {
        System.out.println("I got a degree.");
    }
}

class Undergraduate extends Degree {
    @Override
    public void getDegree() {
        System.out.println("I am an Undergraduate.");
    }
}

class Postgraduate extends Degree {
    @Override
    public void getDegree() {
        System.out.println("I am a Postgraduate.");
    }
}

// Main class to test the implementation
public class DegreeDemo {
    public static void main(String[] args) {
        Degree degree = new Degree();
        degree.getDegree(); // Call method for Degree class

        Degree undergrad = new Undergraduate();
        undergrad.getDegree(); 

        Degree postgrad = new Postgraduate();
        postgrad.getDegree(); 
        
    }
}
