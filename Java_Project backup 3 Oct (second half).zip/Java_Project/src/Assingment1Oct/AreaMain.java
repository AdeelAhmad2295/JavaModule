package Assingment1Oct;
import java.util.*;
public class AreaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter value of a:");
		int a=s.nextInt();
	}

}
