package stringpack;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer("Adeel");
		sb.append(" Cdac Nashik");
		System.out.println("Append String "+sb);
		
		int a=sb.indexOf("l");
		System.out.println("Index is "+a);
		
		int b=sb.lastIndexOf("i");
		System.out.println("Last index is "+b);
		
		sb.replace(6, 17, "B.E");
		System.out.println(sb);
		sb.delete(6, 17);
		System.out.println("Delete String" +sb);
	}

}
