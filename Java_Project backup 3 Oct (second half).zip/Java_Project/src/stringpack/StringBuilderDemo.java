package stringpack;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder("Adeel ");
		sb.insert(6, "Ahmad khan");
		System.out.println(sb);
		
		int a=sb.indexOf("l");
		System.out.println("Index is "+a);
		
		int b=sb.lastIndexOf("d");
		System.out.println("Last index is "+b);
		
		sb.replace(6, 17, "B.E");
		System.out.println(sb);
		sb.delete(6, 17);
		System.out.println("Delete String" +sb);
	}

}
