package stringpack;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=new String(" Adeel Ahmad Khan");
		String str1=new String("Hello");
		System.out.println("SubString  :---------->"+str.substring(7));
		System.out.println("SubString  :---------->"+str.substring(7, 11));
		System.out.println("CompareTo  :---------->"+str.compareTo(str1));
		System.out.println("ToUpperCase:---------->"+str.toUpperCase());
		System.out.println("ToLowerCase:---------->"+str1.toLowerCase());
		System.out.println("Concat     :---------->"+str.concat(str1));
		System.out.println("Trim       :---------->"+str.trim());
		System.out.println("Replace    :---------->"+str.replace("ee", "i"));
		System.out.println("IndexOf    :---------->"+str.indexOf("e"));
		
		String[] arr=str.split(" ");
		for(String s:arr) {
			System.out.println("Split  :---------->"+s);
		}	
		}

}
