package abstractpack;
abstract class BankAccount{
	protected int id;
	protected float balance;
	public abstract float calculateInterest();

	public BankAccount(int id, float balance) {
		super();
		this.id = id;
		this.balance = balance;
	}
}
public class TestBankAccount {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CurrentAccount cur1=new CurrentAccount(1, 25000);
		System.out.println("1. CurrentAccount Interest: "+cur1.calculateInterest());
		System.out.println("===========================================");
		LoanAccount loan=new LoanAccount(2, 25000);
		System.out.println("2. LoanAccount Interest: "+loan.calculateInterest());
		System.out.println("===========================================");
		SavingAccount saving=new SavingAccount(3, 25000);
		System.out.println("3. SavingAccount Interest: "+saving.calculateInterest());
	}
}
