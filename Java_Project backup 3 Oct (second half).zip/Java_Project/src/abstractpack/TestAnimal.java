package abstractpack;

abstract class Animal1 {
    final int leg = 4;

    abstract public void sound();
    abstract public void fun1();
    abstract public void fun2();

    public void classInfo(String type) {
        System.out.println("I belong to " + type + " and have " + leg + " legs.");
    }
}

class Dog extends Animal1 {
    public void sound() {
        System.out.println("The Dog barks...");
    }

    public void fun1() {
        System.out.println("This is fun1 from Dog.");
    }

    public void fun2() {
        System.out.println("This is fun2 from Dog.");
    }
}

class Lion extends Animal1 {
    public void sound() {
        System.out.println("The Lion is roaring...");
    }

    public void fun1() {
        System.out.println("This is fun1 from Lion.");
    }

    public void fun2() {
        System.out.println("This is fun2 from Lion.");
    }
}

public class TestAnimal {
    public static void main(String[] args) {
        Dog animal1 = new Dog();
        animal1.classInfo("Dog");
        animal1.sound();
        animal1.fun1();
        animal1.fun2();

        System.out.println("============================");

        Lion animal2 = new Lion();
        animal2.classInfo("Lion");
        animal2.sound();
        animal2.fun1();
        animal2.fun2();
    }
}
