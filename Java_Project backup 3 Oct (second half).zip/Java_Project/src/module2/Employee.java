package module2;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeClass emp1=new EmployeeClass();
		EmployeeClass emp2=new EmployeeClass();
		emp1.accept();
		emp2.accept();
		System.out.println("--------------**************----------------");
		emp1.display();
		emp1.compleProject();
		emp1.checkAttendance();
		emp1.applyLoan();
		System.out.println("--------------**************----------------");
		emp2.display();
		emp2.compleProject();
		emp2.checkAttendance();
		emp2.applyLoan();
	}

}
