package module3;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("---------FOR LOOP-----------");
		for(int i=1;i<=10;i++) {
		 System.out.println(i+ " Adeel Ahmad Khan ");	
		}
		System.out.println("---------WHILE LOOP-----------");
		int a=1;
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("---------DO WHILE LOOP-----------");
		int b=1;
		do {
			System.out.println(b);
			b++;
		}while(b<10);
	}

}
