package module3;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int choice;
		System.out.println("Enter a Number: ");
		choice=s.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Working Day...");
			break;
		case 2:
			System.out.println("Working Day...");
			break;
		case 3:
			System.out.println("Working Day...");
			break;
		case 4:
			System.out.println("Working Day...");
			break;
		case 5:
			System.out.println("Movie Time...");
			break;
		case 6:
			System.out.println("Super Sunday...");
			break;
		case 7:
			System.out.println("Sleepy Sunday...");
			break;
		default:
			System.out.println("You entered a wrong choice pleace enter between 1-7");
		}
		
	}

}
