package module3;
import java.util.*;
public class IfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int n;
		System.out.println("Enter a Number: ");
		n=s.nextInt();
		if(n>0) {
			System.out.println("Number is Positive..");
		}
		else if(n<0) {
			System.out.println("Number is Negative..");
		}
		else {
			System.out.println("Number is zero..");
		}
	}
}
