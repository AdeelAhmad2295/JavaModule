package module3;

import java.util.Scanner;

public class Digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int n,count=0;
		System.out.println("Enter a Number: ");
		n=s.nextInt();
//		if(n>0 && n<10) {
//			System.out.println("Single Digit number..");
//		}
//		else if(n>=10 && n<100){
//			System.out.println("Two digit number");
//		}
//		else if(n>=100 && n<1000){
//			System.out.println("Three digit number");
//		}
//		else if(n>=1000 && n<10000){
//			System.out.println("Four digit number");
//		}
//		else if(n>=10000 && n<100000){
//			System.out.println("Five digit number");
//		}
//		else {
//			System.out.println("Please enter positive number...");
//		}
	      while(n!=0) {
	            n/=10; 
	            count++;      
	        }
		System.out.println("There are "+count+" digits");
	}

}
