package module3;

import java.util.Scanner;

public class IfDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int n,pow=0,temp=0;
		System.out.println("Enter a Number: ");
		n=s.nextInt();
		if(n>=10 && n<100) {
			pow=n%10;
			temp=n/10;
		}
		else {
			System.out.println("check Number is 0 or greater than 100...");
		}
		System.out.println(n+" rais to "+pow+" is " +Math.pow(temp, pow));
	}

}
