package Module1;
import module2.EmployeeClass;
public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeClass emp=new EmployeeClass();
		emp.accept();
		emp.display();
		emp.compleProject();
		emp.checkAttendance();
		emp.applyLoan();
	}

}
