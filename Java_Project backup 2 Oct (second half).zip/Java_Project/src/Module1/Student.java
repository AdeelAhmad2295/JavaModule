package Module1;

public class Student {
	private int rollno;
	private String name;
	private double score;
	
	public void attendClass() {
		System.out.println("Attending the Class..");
	}
	public void apperExam() {
		System.out.println("Apper for the Exam..");
	}
	public void competeAssignment() {
		System.out.println("Completing the Assignment");
	}
	void display() {
		System.out.println("Roll no is:"+rollno);
		System.out.println("Name of Student:"+name);
		System.out.println("Score of Student:"+score);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Creating an Object:");
		Student student=new Student();
		

	}

}
