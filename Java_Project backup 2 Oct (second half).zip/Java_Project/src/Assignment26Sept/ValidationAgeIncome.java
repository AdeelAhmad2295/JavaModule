/*Assignment 1: Validating Age and Income
Write a program that checks if a person is eligible for a loan based on their age and income.
Requirements:
•    A person is eligible if their age is between 18 and 60 and their income is above $25,000.
•    Use logical && to combine these conditions.*/
package Assignment26Sept;
import java.util.*;
public class ValidationAgeIncome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		System.out.println("Enter the age of Person:");
		int age=s.nextInt();
		System.out.println("Enter the income of Person:");
		int income=s.nextInt();
		if(age>=18 && age<=60 && income>=25000) {
			System.out.println("Person is Eligible.");
		}
		else {
			System.out.println("Person is not Eligible.");
		}
	}

}
