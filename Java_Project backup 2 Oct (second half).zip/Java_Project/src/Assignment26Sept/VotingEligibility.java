/*
 * Assignment 4: Voting Eligibility
Write a program that checks if a person is eligible to vote. A person can vote if they are a citizen and their age is 18 or
 above.
Requirements:
•    Use logical && to combine conditions, and ! to negate conditions if necessary.
 */
package Assignment26Sept;
import java.util.*;
public class VotingEligibility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the age:");
		int age=s.nextInt();
		System.out.println("Enter you are Citizen or not(true/false only): ");
		boolean citizen=s.nextBoolean();
		if(age>18 && citizen==true) {
			System.out.println("You are Eligible for voting.");
		}
		else {
			System.out.println("You are Not Eligible for voting.");
		}
	}

}
