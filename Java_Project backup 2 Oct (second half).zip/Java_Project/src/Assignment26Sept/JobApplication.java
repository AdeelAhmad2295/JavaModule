/*
Assignment 5: Job Application
Write a program that checks if a person is eligible for a job based on their qualifications. 
A person is eligible if they have a bachelor’s degree or equivalent experience, and they have a clean criminal record.
Requirements:
•    Use logical operators to combine conditions.
 */
package Assignment26Sept;
import java.util.*;
public class JobApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		System.out.print("Do you have a bachelor's degree? (true/false): ");
        boolean hasBachelorsDegree = s.nextBoolean();
        System.out.print("Do you have equivalent experience? (true/false): ");
        boolean hasEquivalentExperience = s.nextBoolean();
        System.out.print("Do you have a clean criminal record? (true/false): ");
        boolean hasCleanRecord = s.nextBoolean();      
        if (hasBachelorsDegree && hasEquivalentExperience && hasCleanRecord) {
            System.out.println("You are eligible for the job.");
        } else {
            System.out.println("You are not eligible for the job.");
        }
	}

}
