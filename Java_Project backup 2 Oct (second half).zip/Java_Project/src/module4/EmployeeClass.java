package module4;
import java.util.*;
public class EmployeeClass {
	private int empNo;
	private String name;
	private double bal;
	
	Scanner s=new Scanner(System.in);
	public void accept() {
		System.out.println("Enter the Employee No:");
		empNo=s.nextInt();
		s.nextLine();
		System.out.println("Enter the name:");
		name=s.nextLine();
		System.out.println("Enter the Balance:");
		bal=s.nextInt();
	}
	public void checkEmpNo() {
		if(empNo>0) {
			System.out.println("Valid Employee..");
		}
		else {
			System.out.println("Invalid Employee..");
		}
	}
	public void checkBal() {
		if(bal>0 && bal<100000) {
			System.out.println("valid Balance...");
		}
		else {
			System.out.println("produce the proof.");
		}
	}
	public void display() {
		System.out.println("Employee Id: "+empNo);
		System.out.println("Employee Name:"+name);
		System.out.println("Employee balance:"+bal);
	}
}
