package module4;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserClass user=new UserClass();
		user.accept();
		user.display();
		user.checkAge();
		user.checkSalary();
	}

}
