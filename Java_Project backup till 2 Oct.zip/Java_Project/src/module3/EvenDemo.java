package module3;

public class EvenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1;
		while(n<=20) {
			if(n%2==0) {
				System.out.println(n+" ");
			}
			n++;
		}
	}

}
