package module3;

public class OrDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=1000,b=1000,c=3000;
		if(c>a || a!=b) {
			System.out.println("any one condition is true");
		}
		if(a!=c) {
			System.out.println("both a and c are different ");
		}
		if(a==b) {
			System.out.println("same");
		}
	}

}
