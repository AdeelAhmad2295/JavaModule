/*
 * Assignment 8: Determine the Greatest Number Using Ternary Operator
Write a Java program to find the greatest number among three numbers using the ternary operator.
*Input: Three integer numbers from the user.
*Output: The greatest number among the three entered numbers.
 */
package Assignment26Sept;
import java.util.*;
public class GreatestNumberTernaryOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
        System.out.print("Enter the num-1: ");
        int num1 = s.nextInt();
        System.out.print("Enter the num-2: ");
        int num2 = s.nextInt();
        System.out.print("Enter the num-3: ");
        int num3 = s.nextInt();
        int greater=(num1>num2)?(num1>num3 ?num1:num3):(num2>num3?num2:num3);
        		//(a > b) ? (a > c ? a : c) : (b > c ? b : c)
       System.out.println("Gretest number among 3 is: "+greater);
     }
}

