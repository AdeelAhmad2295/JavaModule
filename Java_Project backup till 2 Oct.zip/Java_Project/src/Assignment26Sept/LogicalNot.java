/*
 * Assignment 6: Logical NOT (!) for Negation
Write a program that determines whether a number is not between 10 and 20 (inclusive).
Requirements:
•    Use logical ! to negate conditions.
 */

package Assignment26Sept;

import java.util.*;

public class LogicalNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner s=new Scanner(System.in);
		System.out.print("Enter a number: ");
        int num=s.nextInt();
        if (!(num >= 10 && num <= 20)) {
            System.out.println("The number is NOT between 10 and 20.");
        } 
        else {
            System.out.println("The number is between 10 and 20.");
        }
	}

}
