package module7;
class Shape{
	void calArea(String shape,int a,int b) {
		System.out.println("calArea of shape class");
	}
	void display() {
		System.out.println("Display of shape class.");
	}
	void fun1() {
		System.out.println("Fun1 of shape class");
	}
}
class Rectangle extends Shape{
	void calArea(String shape,int a,int b) {
		System.out.println("Area is "+(a*b));
	}
	void display() {
		super.display(); 
		super.fun1();
	}

}
public class FunctionOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub.

		Shape shape=new Shape();
		shape.calArea("shape",10,20);
		shape.display();
		
		System.out.println("-----------------------------");
		Rectangle rectangle=new Rectangle(); //static binding
		rectangle.calArea("rectangle", 11, 22);
		rectangle.display();
		
		System.out.println("-----------------------------");
		shape=new Rectangle();//dynamic binding 
		shape.calArea("rectangle", 12, 15);//calls calArea or Recangle Class
		shape.display();
	}

}
