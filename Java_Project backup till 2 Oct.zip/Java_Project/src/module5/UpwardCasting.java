package module5;

public class UpwardCasting {
	public static void main(String fsaf[])
	{
		int a=120;
		double b=a; // upward casting is automatically
		System.out.println(a);
		
		double x=234.34;
		int r=(int)x; // downward casting is explicit
		System.out.println(r);
	}

}
