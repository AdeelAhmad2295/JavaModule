package module5;
class myclass1
{
	public void fun1()
	{
		System.out.println("this is function1");
	}
}
class myclass2
{
	public void fun2()
	{
		System.out.println("this is function2");
	}
}
class myclass3
{
	public void fun3()
	{
		System.out.println("this is function3");
	}
}
public class Myclass {

	public static void main(String[] args) {
		 myclass1 my1=new  myclass1();
		 my1.fun1();
		 myclass2 my2=new  myclass2();
		 my2.fun2();
		 myclass3 my3=new  myclass3();
		 my3.fun3();

	}

}
