package module5;

public class Circle {

	public static void main(String[] args) {
		
		TestCircle circle=new TestCircle();
		TestCircle circle1=new TestCircle();
		TestCircle circle2=new TestCircle();
        circle.accept();
        circle.callarea();
        circle.callperi();
        circle.display();
        // hashCode()---> returns the memmory address
        System.out.println(circle.hashCode());
        System.out.println(circle1.hashCode());
        System.out.println(circle2.hashCode());
        
        //compare objects---> equals
          boolean result = circle.equals(circle2);
          System.out.println(result);
	}
}
