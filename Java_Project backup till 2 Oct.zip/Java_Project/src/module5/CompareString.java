package module5;

public class CompareString {
 
	public static void main(String ghdk[])

	{
		int a=300;
		int b=300;
		if(a==b)
		{
			System.out.println("same");
		}
		String str1="Sakshi";
		String str2="Sakshi";
		if(str1==str2)
		
            System.out.println("same");
		else
			System.out.println("not same");
		
		// 2nd method
		String str3=new String("Diya");
		String str4 =new String("Diya");
		if(str3.equals(str4))
		{
			System.out.println("same");
		}
		else
			System.out.println("not same");
		/// 3rd method
		if(str3.equals("diya"))
		{
			System.out.println("same");
		}
		else
			System.out.println("not same........");
		
		// equalsIgnoreCase--> ignores capital and small
		if(str3.equalsIgnoreCase(str4))
		{
			System.out.println("same");
		}
		else
			System.out.println("not same");
		
	}
}
