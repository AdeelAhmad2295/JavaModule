package module5;
public class Overload_Main {

	public void main()
	{
		System.out.println("main method without parameters");
	}
	public void main(int a)
	{
		System.out.println("main method with 1 parameters");
	}
	public void main(int a, int b)
	{
		System.out.println("main method with 2 parameters");
	}
	public void main(int a, int b,double c)
	{
		System.out.println("main method with 3 parameters");
	}
	public void main(double a, double b,double c,double e)
	{
		System.out.println("main method with 4 parameters");
	}
	public static void main(String adfasf[])
	{
		 Overload_Main obj=new  Overload_Main();
		 obj.main();
		 obj.main(3);
		 obj.main(10, 20);
		 obj.main(10, 20, 30.55);
		 obj.main(10.55, 20.45, 30.35, 40.25);
	}
}
