package module4;
import java.util.*;
public class UserClass {
	private String name;
	private int age;
	private int sal;
	Scanner s=new Scanner(System.in);
	public void accept() {
		System.out.println("Enter the name:");
		name=s.nextLine();
		System.out.println("Enter the Age:");
		age=s.nextInt();
		System.out.println("Enter the Salary:");
		sal=s.nextInt();
	}
	public void checkAge() {
		if(age>18) {
			System.out.println("You are eligible for vote.0");
		}
		else if(age>18 && age<100) {
			System.out.println("Your age is valid.");
		}
		else {
			System.out.println("invalid age.");
		}
	}
	public void checkSalary() {
		if(sal>0 && sal<100000) {
			System.out.println("salary is valid.");
		}
		else {
			System.out.println("Salary is invalid.");
		}
	}
	public void display() {
		System.out.println("Name: "+name);
		System.out.println("Age:"+age);
		System.out.println("Salary:"+sal);
	}
}
