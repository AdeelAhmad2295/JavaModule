package Module1;
public class Myclass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
		
		System.out.println(10>5&& 5<3);
		System.out.println(x++);
	}
}
