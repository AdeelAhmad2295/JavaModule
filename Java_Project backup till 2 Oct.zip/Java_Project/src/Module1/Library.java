package Module1;

public class Library {
	private String book_name;
	private String book_author_name;
	private int book_id;
	private int year;
	private int book_price;
	
	public void get_data(String book_name,String book_author_name,int book_id,int year,int book_price) {
		this.book_name=book_name;
		this.book_author_name=book_author_name;
		this.book_id=book_id;
		this.year=year;
		this.book_price=book_price;
	}
	public void show_data() {
		System.out.println("Book name is:"+book_name);
		System.out.println("Book Author name is:"+book_author_name);
		System.out.println("Book Id is:"+book_id);
		System.out.println("Book Published in:"+year);
		System.out.println("Book Price is:"+book_price);
	}
	public void Borrow() {
		System.out.println("name the Book which you can borrow:");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library obj1=new Library();
		System.out.println("----------------*********************-----------------");
		obj1.book_name="Java";
		obj1.book_author_name="James Gosling";
		obj1.book_id=1024;
		obj1.year=2012;
		obj1.book_price=250;
		obj1.show_data();
		System.out.println("----------------*********************-----------------");
		Library obj2=new Library();
		obj2.book_name="C++";
		obj2.book_author_name="Dennis Ritchie";
		obj2.book_id=1025;
		obj2.year=2008;
		obj2.book_price=195;
		obj2.show_data();
		System.out.println("----------------*********************-----------------");
		Library obj3=new Library();
		obj3.book_name="Python";
		obj3.book_author_name="Guido Van Rossum ";
		obj3.book_id=1026;
		obj3.year=2015;
		obj3.book_price=155;
		obj3.show_data();
		System.out.println("----------------*********************-----------------");
		
	}

}
