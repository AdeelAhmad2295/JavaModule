package Module1;

public class Myclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub library class and attributes
		int emp=100;
		String name="Adeel Ahmad";
		double sal=60000.00;
		float comm=2000.00f;
		float bonus=(float)4000.00;
		byte b=100;
		short s=2000;
		long l=112233445566l;
		char gender='M';
		boolean passStatus=true;
		System.out.println("Employee No: "+emp);
		System.out.println("Employee Name: "+name);
		System.out.println("Employee Salary: "+sal);
		System.out.println("Employee comm: "+comm);
		System.out.println("Employee Bonus: "+bonus);
		System.out.println("Byte: "+b);
		System.out.println("Short: "+s);
		System.out.println("Long: "+l);
		System.out.println("Gender: "+gender);
		System.out.println("Employee Pass/Fail: "+passStatus);


	}

}
