package module6;
import java.util.*;
public class MultiDimenArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value of Rows: ");
		int n=s.nextInt();
		System.out.println("Enter the value of Column: ");
		int m=s.nextInt();
		int arr[][]=new int[n][m];
		System.out.println("Enter Array Elements:");
		for(int i=0;i<n;i++) {
			for (int j=0;j<m;j++) {
				arr[i][j]=s.nextInt();
			}
		}
		System.out.println("RollNo\t|\tjava\t|\tCPP\t|\tMySql\t|");
		for(int i=0;i<n;i++) {
			for (int j=0;j<m;j++) {
				System.out.print(arr[i][j]+"\t|\t");
			}
			System.out.println();
		}
		
	}

}
