package module6;
import java.util.Scanner;
public class Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		System.out.println("Enter Account Number:");
		int accNo=s.nextInt();
		System.out.println("Enter Account Holder Name: ");
		String accName=s.next();
		System.out.println("Enter Account Balance:");
		double accbalance=s.nextDouble();
		AccountClass per1=new AccountClass();
		per1.setAccNo(accNo);
		per1.setAccName(accName);
		per1.setAccBalance(accbalance);
		System.out.println(per1);
		System.out.println("=====================================");
		AccountClass per2=new AccountClass(455631,"AdeelAhmad",42345.50);
		System.out.println(per2);
	}

}
