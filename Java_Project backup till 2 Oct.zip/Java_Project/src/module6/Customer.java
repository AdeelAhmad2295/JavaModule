package module6;
import java.util.*;
public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Customer Id:");
		int cusId=s.nextInt();
		System.out.println("Enter Customer Name:");
		String name=s.next();
		System.out.println("Enter Mobile No:");
		String mob=s.next();
		System.out.println("Enter Customer Address:");
		String address=s.next();
		CustomerClass customer=new CustomerClass();
		customer.setCusId(cusId);
		customer.setName(name);
		customer.setMob(mob);
		customer.setAddress(address);
		System.out.println(customer);
		//		std.display();
//		System.out.println("displaying Details.......");
//		System.out.println("Customer id: "+customer.getCusId());
//		System.out.println("Name of customer: "+customer.getName());
//		System.out.println("customer Mobile Number: "+customer.getMob());
//		System.out.println("Customer Address: "+customer.getAddress());
	    System.out.println("============================================");
		CustomerClass customer1=new CustomerClass(01,"Adeel","(+91)9172826776","Akola");
//		System.out.println("displaying Details.......");
//		System.out.println("Customer id: "+customer1.getCusId());
//		System.out.println("Name of customer: "+customer1.getName());
//		System.out.println("customer Mobile Number: "+customer1.getMob());
//		System.out.println("Customer Address: "+customer1.getAddress());		
		System.out.println(customer1);
	}

}
