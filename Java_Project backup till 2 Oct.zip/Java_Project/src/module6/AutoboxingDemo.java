package module6;

public class AutoboxingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		Integer i=a;   //Autoboxing
		System.out.println("=========================");
		int a1=i;  //Unboxing 
		System.out.println(i);
	}

}
