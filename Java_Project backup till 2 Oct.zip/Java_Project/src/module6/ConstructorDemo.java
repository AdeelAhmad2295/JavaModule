package module6;
import java.util.*;
public class ConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter rollNo:");
		int rollNo=s.nextInt();
		System.out.println("Enter Name:");
		String name=s.next();
		System.out.println("Enter Score:");
		double score=s.nextDouble();
		ConstructorDemoClass std=new ConstructorDemoClass();
		std.setRollNo(rollNo);
		std.setName(name);
		std.setScore(score);
//		std.display();
		System.out.println("displaying Details.......");
		System.out.println("Roll No "+std.getRollNo());
		System.out.println("Name "+std.getName());
		System.out.println("Score "+std.getScore());
		
		std.markAttendance();
		System.out.println("=====================");
		ConstructorDemoClass std1=new ConstructorDemoClass(2,"Adeel",95);
//		std1.display();
		System.out.println("displaying Details.......");
		System.out.println("Roll No "+std1.getRollNo());
		System.out.println("Name "+std1.getName());
		System.out.println("Score "+std1.getScore());
		std1.markAttendance();
		System.out.println("===========================");
		System.out.println("Changing the name..");
		System.out.println("Enter new name :");
		name=s.next();
		std1.setName(name);
		System.out.println("Roll No "+std1.getRollNo());
		System.out.println("Name "+std1.getName());
		System.out.println("Score "+std1.getScore());
	}

}
