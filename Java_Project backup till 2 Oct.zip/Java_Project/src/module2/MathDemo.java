package module2;

public class MathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.sqrt(144));
		System.out.println(Math.abs(-55));
		System.out.println(Math.min(35, 45));
		System.out.println(Math.max(54, 75));
		System.out.println(Math.random());
		System.out.println(Math.random()*100);
		double d=(int)(Math.random()*10000);
		System.out.println(d);
		System.out.println(Math.ceil(979.45));
		System.out.println(Math.floor(979.66));
		System.out.println(Math.round(755.45));
		System.err.println(Math.pow(4,3));
		
	}
}
