package module2;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentClass student1=new StudentClass();
//		student1.accept();
		student1.attendClass();
		student1.competeAssignment();
		student1.apperExam();
		student1.display();
		System.out.println("---------------**************-----------------");
		StudentClass student2=new StudentClass();
//		student2.accept();
		student2.attendClass();
		student2.competeAssignment();
		student2.apperExam();
		student2.display();
		System.out.println("---------------**************-----------------");
	}

}
