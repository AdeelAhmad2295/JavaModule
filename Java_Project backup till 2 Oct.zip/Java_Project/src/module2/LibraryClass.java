package module2;
import java.util.*;
public class LibraryClass {
	private int bookId;
	private String bookName;
	private String bookAuthorName;
	private int year;
	private int bookPrice;
	private String borrow;
	public String returnBook;
	public String fine;
	Scanner s=new Scanner(System.in);
	public void addBook() {
		System.out.println("Enter the Book id: ");
		bookId=s.nextInt();
		System.out.println("Enter Book Name: ");
		s.nextLine();
		bookName=s.nextLine();
		s.nextLine();
		System.out.println("Enter Book Author Name: ");
		bookAuthorName=s.nextLine();
		System.out.println("Enter Published Year: ");
		year=s.nextInt();
		System.out.println("Enter Book Price: ");
		bookPrice=s.nextInt();
	}
	public void borrowBook() {
		System.err.println("Which book you borrow from library: ");
		s.nextLine();
		borrow=s.nextLine();
	}
	public void returnBook() {
		System.err.println("Which book do you return to library: ");
		returnBook=s.nextLine();
	}
	public void fine() {
		System.out.println("Check submit before deadline or not(Y/N): ");
		fine=s.nextLine();
		
	}
	public void displayData() {
		System.out.println("Book Id: "+bookId);
		System.out.println("Book Name: "+bookName);
		System.out.println("Author Name: "+bookAuthorName);
		System.out.println("Published year: "+year);
		System.out.println("Book Price: "+bookPrice);
		System.out.println("Borrow Book name: "+borrow);
		System.out.println("Return Book name: "+returnBook);
		if(fine.charAt(0)=='Y') {
			System.out.println("No fine..");
		}
		else {
			System.out.println("30 rupees fine...due to submit after deadline..");
		}
	}
	
}
