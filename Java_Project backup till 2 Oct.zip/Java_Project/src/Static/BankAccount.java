package Static;

public class BankAccount {
	private int accNo;
	private double balance;
	private static int idNum=1;
	
	public BankAccount(){
		accNo=idNum++;
		balance=0;
	}
	
	public BankAccount(double balance) 
	{
		this.accNo=idNum++;
		this.balance = balance;
	}
	public static int getIdNum() {
		return idNum;
	}
	

	@Override
	public String toString() {
		return "\taccNo = " + accNo + "\tbalance=" + balance;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount bankAccount1=new BankAccount(4563.54);
		System.out.println(bankAccount1);
		
		BankAccount bankAccount2=new BankAccount(4500);
		System.out.println(bankAccount2);
		
		BankAccount bankAccount3=new BankAccount(60000);
		System.out.println(bankAccount3);
		
	}

}
