package module4;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeClass emp=new EmployeeClass();
		emp.accept();
		emp.checkEmpNo();
		emp.checkBal();
		emp.display();
	}

}
