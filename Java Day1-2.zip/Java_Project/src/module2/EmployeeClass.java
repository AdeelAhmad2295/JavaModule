package module2;
import java.util.*;
public class EmployeeClass {
	 private int empNo;
	 private String name;
	 private double empSal;
	Scanner s=new Scanner (System.in);
	public void accept() {
	    System.out.println("Enter Employee NO:");
	    empNo = s.nextInt();
	    s.nextLine();
	    System.out.println("Enter Name of Employee:");
	    name = s.nextLine();
	    System.out.println("Enter Salary:");
	    empSal = s.nextDouble();

	}
	public void display() {
		System.out.println("Employee No: "+empNo);
		System.out.println("Employee Name: "+name);
		System.out.println("Employee Salary: "+empSal);
		
	}
	public void compleProject() {
			System.out.println(name+ " Project Completed in given deadline.");	
	}
	public void checkAttendance() {
		System.out.println(name+ " Attendance is above 85%.");
	}
	public void applyLoan() {
		System.out.println(name+ " is not Applied for Loan.");
	}
}
