package module2;

public class Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LibraryClass m1=new LibraryClass();
		m1.addBook();
		m1.borrowBook();
		m1.returnBook();
		m1.fine();
		m1.displayData();
		
	}

}
