package module2;
import java.util.*;


public class StudentClass {
	 private int rollno;
	 private String name;
	 private double score;
	Scanner s=new Scanner (System.in);
	public void accept() {
	    System.out.println("Enter Roll NO:");
	    rollno = s.nextInt();
	    s.nextLine(); // Consume the leftover newline
	    System.out.println("Enter Name of Student:");
	    name = s.nextLine();
	    System.out.println("Enter Score:");
	    score = s.nextDouble();
	}

	public void attendClass() {
		System.out.println("Attending the Class..");
	}
	public void apperExam() {
		System.out.println("Apper for the Exam..");
	}
	public void competeAssignment() {
		System.out.println("Completing the Assignment");
	}
	void display() {
		System.out.println("Roll no is:"+rollno);
		System.out.println("Name of Student:"+name);
		System.out.println("Score of Student:"+score);
		
	}		
}
